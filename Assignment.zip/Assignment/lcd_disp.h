#ifndef LCD_DISP_
#define LCD_DISP_

void LCD_Clear();
void LCD_disp_init();
void LCD_disp_update(Int16 mode, Int16 b1, Int16 b2, Int16 b3);


#endif /*LCD_DISP_*/
